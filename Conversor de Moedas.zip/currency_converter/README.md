# Conversor de Moedas em Java

Este é um projeto simples de conversor de moedas desenvolvido em Java, utilizando Maven para gerenciamento de dependências e build. Ele demonstra a conversão entre algumas moedas com taxas de câmbio mockadas.

## Funcionalidades

- Conversão entre USD, BRL e EUR.
- Adição de novas taxas de câmbio.

## Como Compilar e Executar

Para compilar e executar este projeto, você precisará ter o Java Development Kit (JDK) 11 ou superior e o Apache Maven instalados em sua máquina.

### 1. Clone o Repositório (se estiver no GitHub)

```bash
git clone https://github.com/seu-usuario/currency-converter.git
cd currency-converter
```

### 2. Compile o Projeto

Navegue até o diretório raiz do projeto (`currency_converter`) e execute o seguinte comando Maven:

```bash
mvn clean install
```

Este comando irá compilar o código-fonte, executar quaisquer testes (se houver) e empacotar o projeto em um arquivo JAR no diretório `target/`.

### 3. Execute o Aplicativo

Após a compilação, você pode executar o aplicativo a partir do arquivo JAR gerado:

```bash
java -jar target/currency-converter-1.0-SNAPSHOT.jar
```

Você verá a saída da conversão de moedas no console.

## Estrutura do Projeto

```
currency_converter/
├── pom.xml
├── src/
│   ├── main/
│   │   └── java/
│   │       └── com/
│   │           └── example/
│   │               └── currencyconverter/
│   │                   ├── CurrencyConverter.java
│   │                   └── Main.java
│   └── test/
│       └── java/
│           └── com/
│               └── example/
│                   └── currencyconverter/
└── README.md
```

- `pom.xml`: Arquivo de configuração do Maven.
- `src/main/java/com/example/currencyconverter/CurrencyConverter.java`: Contém a lógica principal para a conversão de moedas e o gerenciamento das taxas de câmbio.
- `src/main/java/com/example/currencyconverter/Main.java`: Ponto de entrada do aplicativo, demonstra o uso da classe `CurrencyConverter`.
- `src/test/java/com/example/currencyconverter/`: Diretório para futuros testes unitários.

## Contribuição

Sinta-se à vontade para fazer um fork deste repositório, propor melhorias e enviar pull requests. Para grandes mudanças, por favor, abra uma issue primeiro para discutir o que você gostaria de mudar.

## Licença

Este projeto está licenciado sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes. (A ser criado)


