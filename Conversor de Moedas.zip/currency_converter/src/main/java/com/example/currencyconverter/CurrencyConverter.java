package com.example.currencyconverter;

import java.util.HashMap;
import java.util.Map;

public class CurrencyConverter {

    private Map<String, Double> exchangeRates;

    public CurrencyConverter() {
        this.exchangeRates = new HashMap<>();
        // Taxas de câmbio mockadas para demonstração
        exchangeRates.put("USD_BRL", 5.20);
        exchangeRates.put("BRL_USD", 1 / 5.20);
        exchangeRates.put("EUR_BRL", 6.00);
        exchangeRates.put("BRL_EUR", 1 / 6.00);
        exchangeRates.put("USD_EUR", 0.85);
        exchangeRates.put("EUR_USD", 1 / 0.85);
    }

    public double convert(String fromCurrency, String toCurrency, double amount) {
        String key = fromCurrency.toUpperCase() + "_" + toCurrency.toUpperCase();
        if (exchangeRates.containsKey(key)) {
            return amount * exchangeRates.get(key);
        } else if (fromCurrency.equalsIgnoreCase(toCurrency)) {
            return amount;
        } else {
            throw new IllegalArgumentException("Taxa de câmbio para " + fromCurrency + " para " + toCurrency + " não encontrada.");
        }
    }

    public void addExchangeRate(String fromCurrency, String toCurrency, double rate) {
        String key = fromCurrency.toUpperCase() + "_" + toCurrency.toUpperCase();
        exchangeRates.put(key, rate);
    }
}


