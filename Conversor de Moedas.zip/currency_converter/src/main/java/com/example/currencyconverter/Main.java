
package com.example.currencyconverter;

public class Main {
    public static void main(String[] args) {
        CurrencyConverter converter = new CurrencyConverter();

        try {
            double amountUSD = 100.0;
            double convertedBRL = converter.convert("USD", "BRL", amountUSD);
            System.out.printf("%.2f USD é igual a %.2f BRL\n", amountUSD, convertedBRL);

            double amountBRL = 500.0;
            double convertedEUR = converter.convert("BRL", "EUR", amountBRL);
            System.out.printf("%.2f BRL é igual a %.2f EUR\n", amountBRL, convertedEUR);

            double amountEUR = 50.0;
            double convertedUSD = converter.convert("EUR", "USD", amountEUR);
            System.out.printf("%.2f EUR é igual a %.2f USD\n", amountEUR, convertedUSD);

            // Testando uma taxa não encontrada
            // converter.convert("JPY", "USD", 1000.0);

        } catch (IllegalArgumentException e) {
            System.err.println("Erro: " + e.getMessage());
        }
    }
}


